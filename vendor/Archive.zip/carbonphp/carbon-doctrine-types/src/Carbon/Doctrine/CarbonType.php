<?php

namespace Carbon\Doctrine;

class CarbonType extends DateTimeType implements CarbonDoctrineType
{
}
